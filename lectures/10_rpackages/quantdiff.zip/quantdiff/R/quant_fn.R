#' Compute a difference in quantiles (one sentence describing what your fn does)
#' 
#' This function returns the difference between two quantiles of a given vector 
#' (a more detailed description of what the function is and how
#' it works).
#'
#' @param x A \code{numeric} vector
#' @param q1 Quantile 1
#' @param q2 Quantile 2
#'
#' @return The difference between quantile \code{q2} and quantile \code{q1}.
#'
#' @importFrom stats quantile
#' @export
#' 
#' @examples
#' x <- rnorm(25)
#' quant_diff(x, 0.25, 0.75)

quant_diff <- function(x, q1, q2){
  quants <- stats::quantile(x, p = c(q1, q2))
  return(quants[2] - quants[1])
}
